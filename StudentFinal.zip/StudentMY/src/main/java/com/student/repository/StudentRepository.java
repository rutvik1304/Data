package com.student.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.student.DTO.StudentDTO;
import com.student.entities.Student;

public interface StudentRepository extends JpaRepository<Student, Long>{
	
	@Query ("select new com.student.DTO.StudentDTO(s.name,s.category,s.start_time,s.end_time,s.frequency"+") from Student s")
	List<StudentDTO> findAllStudentDTOs();
	
	@Query ("select new com.student.DTO.StudentDTO(s.name,s.category,s.start_time,s.end_time,s.frequency"+") from Student s where s.id = :id")
	StudentDTO findByIdDTO(@Param("id") Long id);


}
