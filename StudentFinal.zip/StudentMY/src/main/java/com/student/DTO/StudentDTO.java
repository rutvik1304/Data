package com.student.DTO;

import java.time.LocalDateTime;

import com.student.entities.Category;

public class StudentDTO {
	
	private String name;
	private Category category;
	private LocalDateTime start_time;
	private LocalDateTime end_time;
	private int frequency;
	
	public StudentDTO(String name, Category category, LocalDateTime start_time, LocalDateTime end_time, int frequency) {
		super();
		this.name = name;
		this.category = category;
		this.start_time = start_time;
		this.end_time = end_time;
		this.frequency = frequency;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Category getCategory() {
		return category;
	}
	public void setCategory(Category category) {
		this.category = category;
	}
	public LocalDateTime getStart_time() {
		return start_time;
	}
	public void setStart_time(LocalDateTime start_time) {
		this.start_time = start_time;
	}
	public LocalDateTime getEnd_time() {
		return end_time;
	}
	public void setEnd_time(LocalDateTime end_time) {
		this.end_time = end_time;
	}
	public int getFrequency() {
		return frequency;
	}
	public void setFrequency(int frequency) {
		this.frequency = frequency;
	}
	

	
}
