package com.student.service;

import java.util.List;

import com.student.DTO.StudentDTO;
import com.student.entities.Student;

public interface StudentService {
	
	List<StudentDTO> getALL();
	
	StudentDTO findById(Long id);
	
	Student addStudent(Student student);
	
	String delStudent(Long id);

}
