package com.student.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.student.DTO.StudentDTO;
import com.student.entities.Student;
import com.student.repository.StudentRepository;

@Service
@Transactional
public class StudentServiceImpl implements StudentService {
	
	@Autowired
	private StudentRepository StudentRepository;
	
	
	@Override
	public List<StudentDTO> getALL() {
		return StudentRepository.findAllStudentDTOs();
	}
	
	@Override
	public Student addStudent(Student student) {
		return StudentRepository.save(student);
	}
	
	@Override
	public String delStudent(Long id) {
		StudentRepository.deleteById(id);
		return "Student deleted successfully";
	}
	
	@Override
	public StudentDTO findById(Long id) {
		return StudentRepository.findByIdDTO(id);
	}

	
}
