package com.student.entities;

public enum Category {
	EXPRESS,SHATABDI,AC,METRO
}
