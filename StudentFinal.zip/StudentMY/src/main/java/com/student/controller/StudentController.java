package com.student.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.student.DTO.StudentDTO;
import com.student.entities.Student;
import com.student.service.StudentService;

import io.swagger.v3.oas.annotations.parameters.RequestBody;

@RestController
@RequestMapping("/students")
public class StudentController {
	
	@Autowired
	private StudentService studentService;
	
	public StudentController()
	{
		System.out.println("in ctor of" + getClass());
	}
	
	@GetMapping
	public List<StudentDTO> list()
	{
		return studentService.getALL();
	}
	
	@GetMapping("/{id}")
	public StudentDTO findById(@PathVariable Long id)
	{
		return studentService.findById(id);
	}
	
	@PostMapping
	public Student addStudent(@RequestBody Student student)
	{
		return studentService.addStudent(student);
	}
	
	@DeleteMapping("/{id}")
	public String delStudent(@PathVariable Long id)
	{
		studentService.delStudent(id);
		return "deleted successfully";
	}

}
