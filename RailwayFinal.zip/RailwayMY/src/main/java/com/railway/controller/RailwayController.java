package com.railway.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.railway.DTO.RailwayDTO;
import com.railway.entities.Railway;
import com.railway.service.RailwayService;

import io.swagger.v3.oas.annotations.parameters.RequestBody;

@RestController
@RequestMapping("/railways")
public class RailwayController {
	
	@Autowired
	private RailwayService railwayService;
	
	public RailwayController()
	{
		System.out.println("in ctor of" + getClass());
	}
	
	@GetMapping
	public List<RailwayDTO> list()
	{
		return railwayService.getALL();
	}
	
	@GetMapping("/{id}")
	public RailwayDTO findById(@PathVariable Long id)
	{
		return railwayService.findById(id);
	}
	
	@PostMapping
	public Railway addRail(@RequestBody Railway railway)
	{
		return railwayService.addRailway(railway);
	}
	
	@DeleteMapping("/{id}")
	public String delRail(@PathVariable Long id)
	{
		railwayService.delRail(id);
		return "deleted successfully";
	}

}
