package com.railway.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.railway.DTO.RailwayDTO;
import com.railway.entities.Railway;
import com.railway.repository.RailwayRepository;

@Service
@Transactional
public class RailwayServiceImpl implements RailwayService {
	
	@Autowired
	private RailwayRepository railwayRepository;
	
	@Override
	public List<RailwayDTO> getALL() {
		return railwayRepository.findAllRailwayDTOs();
	}
	
	@Override
	public Railway addRailway(Railway rail) {
		return railwayRepository.save(rail);
	}
	
	@Override
	public String delRail(Long id) {
		railwayRepository.deleteById(id);
		return "Railway dleted successfully";
	}
	
	@Override
	public RailwayDTO findById(Long id) {
		return railwayRepository.findByIdDTO(id);
	}

	
}
