package com.railway.service;

import java.util.List;

import com.railway.DTO.RailwayDTO;
import com.railway.entities.Railway;

public interface RailwayService {
	
	List<RailwayDTO> getALL();
	
	RailwayDTO findById(Long id);
	
	Railway addRailway(Railway rail);
	
	String delRail(Long id);

}
