package com.railway.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.railway.DTO.RailwayDTO;
import com.railway.entities.Railway;

public interface RailwayRepository extends JpaRepository<Railway, Long>{
	
	@Query ("select new com.railway.DTO.RailwayDTO(r.name,r.category,r.start_time,r.end_time,r.frequency"+") from Railway r")
	List<RailwayDTO> findAllRailwayDTOs();
	
	@Query ("select new com.railway.DTO.RailwayDTO(r.name,r.category,r.start_time,r.end_time,r.frequency"+") from Railway r where r.id = :id")
	RailwayDTO findByIdDTO(@Param("id") Long id);


}
