package com.railway.entities;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="railway")
public class Railway {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	//@GeneratedValue(strategy = GenerationType.AUTO);
	private long id;
	@Column(length=20)
	private String name;
	@Enumerated(EnumType.STRING)
	@Column(length=20)
	private Category category;
	private LocalDateTime start_time;
	private LocalDateTime end_time;
	@Column(length=20)
	private String source;
	@Column(length=20)
	private String destination;
	@Column(length=20)
	private int station_code;
	@Column(length=20)
	private int distance;
	@Column(length=20)
	private int frequency;
	
	public Railway() {
		
	}
	
	public Railway(String name, Category category, LocalDateTime start_time, LocalDateTime end_time,String source,
			String destination, int station_code, int distance, int frequency) {
		this.name=name;
		this.category=category;
		this.start_time=start_time;
		this.end_time=end_time;
		this.source=source;
		this.destination=destination;
		this.station_code=station_code;
		this.distance=distance;
		this.frequency=frequency;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public LocalDateTime getStart_time() {
		return start_time;
	}

	public void setStart_time(LocalDateTime start_time) {
		this.start_time = start_time;
	}

	public LocalDateTime getEnd_time() {
		return end_time;
	}

	public void setEnd_time(LocalDateTime end_time) {
		this.end_time = end_time;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public int getStation_code() {
		return station_code;
	}

	public void setStation_code(int station_code) {
		this.station_code = station_code;
	}

	public int getDistance() {
		return distance;
	}

	public void setDistance(int distance) {
		this.distance = distance;
	}

	public int getFrequency() {
		return frequency;
	}

	public void setFrequency(int frequency) {
		this.frequency = frequency;
	}
	
	@Override
	public String toString() {
		return "Railway [name=" + name + ", category=" + category + ", start_time=" + start_time + ", end_time="
				+ end_time + ", source=" + source + ", destination=" + destination + ", station_code=" + station_code
				+ ", distance=" + distance + ", frequency=" + frequency + "]";
	}
	

}
