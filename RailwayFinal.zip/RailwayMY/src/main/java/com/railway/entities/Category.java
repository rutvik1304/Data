package com.railway.entities;

public enum Category {
	EXPRESS,SHATABDI,AC,METRO
}
